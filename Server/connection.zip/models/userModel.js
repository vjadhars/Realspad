const mongoose = require("mongoose");

const schema = mongoose.Schema({
    walletAddress:{
        type:String,
        required:true,
    },
    points:{
        type:String,
        required:true
    }
})

const RealspadPoints = mongoose.model("RealspadPoints", schema);
module.exports = RealspadPoints;