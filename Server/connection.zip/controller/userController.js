const RealspadPoints = require("../models/userModel");

exports.addPoints = async (req, res) => {
    try {
        let { walletAddress } = req.body
        let find_data = await RealspadPoints.findOne({ walletAddress: walletAddress })
        if (find_data == null) {
            const data = new RealspadPoints(req.body);
            await data.save();
            res.status(201).send({
                success: true,
                msg: "Data Store Successfuly"
            })
        } else {
            res.status(201).send({
                success: false,
                msg: "This Address is already exist"
            })
        }
    } catch (error) {
        console.error("error while get user", error);
    }
}

exports.getByAddress = async (req, res) => {
    try {

        let {
            walletAddress
        } = req.query

        const data = await RealspadPoints.findOne({
            walletAddress: walletAddress
        })
        // console.log("data", data);
        if (data !== null) {
            res.status(201).send({
                data: data,
                success: true,
            })
        } else {
            res.status(200).send({
                data: [],
                success: false,
            })
        }
    } catch (error) {
        console.error("error while get user", error);
    }
}